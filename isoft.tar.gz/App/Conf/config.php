<?php 
return array(
'URL_MODEL'=>'3',
'DB_TYPE'=>'mysql',
'DB_HOST'=>'localhost',
'DB_NAME'=>'isoft_wms',
'DB_USER'=>'root',
'DB_PWD'=>'root',
'DB_PORT'=>'3306',
'DB_PREFIX'=>'twms_',
'DB_FIELDS_CACHE' =>false,
'PAGE_SIZE'=>15,
'INDEX_NOTICE_PAGE_SIZE'=>8
);
?>
