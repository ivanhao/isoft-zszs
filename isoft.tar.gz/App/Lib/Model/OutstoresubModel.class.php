<?php
class OutstoresubModel extends Model {
	protected $tableName='outstore_sub';
}
?>