<?php
class StockModel extends Model {
	protected $tableName='stock';
}
?>