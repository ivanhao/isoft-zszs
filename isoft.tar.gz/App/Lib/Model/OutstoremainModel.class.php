<?php
class OutstoremainModel extends Model {
	protected $tableName='outstore_main';
}
?>