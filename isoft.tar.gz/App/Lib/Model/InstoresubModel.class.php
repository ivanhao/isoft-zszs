<?php
class InstoresubModel extends Model {
	protected $tableName='instore_sub';
}
?>