<?php
class SettingModel extends Model {
	protected $tableName='setting';
}
?>