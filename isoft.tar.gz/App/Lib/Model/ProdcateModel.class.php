<?php
class ProdcateModel extends Model {
	protected $tableName='prod_cate';
}
?>