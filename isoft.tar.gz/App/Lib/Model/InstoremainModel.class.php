<?php
class InstoremainModel extends Model {
	protected $tableName='instore_main';
}
?>