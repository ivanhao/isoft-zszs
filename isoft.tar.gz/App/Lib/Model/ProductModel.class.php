<?php
class ProductModel extends Model {
	protected $tableName='product';
}
?>