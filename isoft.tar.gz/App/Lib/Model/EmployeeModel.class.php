<?php
class EmployeeModel extends Model {
	protected $tableName='employee';
}
?>