<?php
class SupplierModel extends Model {
	protected $tableName='supplier';
}
?>