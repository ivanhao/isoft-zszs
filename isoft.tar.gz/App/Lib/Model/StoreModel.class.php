<?php
class StoreModel extends Model {
	protected $tableName='store';
}
?>