<?php
class CustomerModel extends Model {
	protected $tableName='customer';
}
?>