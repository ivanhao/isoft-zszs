<?php
header('Location:./index.php?s=/Install/index');
?>